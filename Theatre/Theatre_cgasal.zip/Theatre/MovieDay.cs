﻿
namespace Theatre_Assignment
{
    enum MovieDay
    {
        Mon, Tue, Wed, Thu, Fri, Sat, Sun
    }
}