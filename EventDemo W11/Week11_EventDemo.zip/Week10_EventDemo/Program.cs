﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week10_EventDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //PersonTester.Run();
            //CollectionDemo.ListDemo();
            //CollectionDemo.HashSetDemo();
            CollectionDemo.DictionaryDemo();
        }
    }
}
